## How to use
How to use:

* Place the folder “ProceduralUIShapes” somewhere in you asset folder
* Right click on the canvas in the Hierarchy and select UI -> RoundedRect
* Make sure that the shader channels TexCoord1, -2 and -3″ are enabled on the canvas component under “Additional Shader Channels”
## License
Public domain, https://creativecommons.org/publicdomain/zero/1.0/
## Read more
http://larshagen.dk/2020/01/19/shader-based-rounded-rectangle-for-ui/